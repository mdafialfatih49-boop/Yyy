package com.packsanimals.entity;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.recipe.Ingredient;
import net.minecraft.world.World;

/** Basis semua hewan mod: AI sederhana (berenang, kabur saat diserang, mengikuti makanan, berkeliaran). */
public abstract class PackAnimalEntity extends PathAwareEntity {

    protected PackAnimalEntity(EntityType<? extends PathAwareEntity> type, World world) {
        super(type, world);
    }

    /** Item yang membuat hewan ini mengikuti pemain. */
    protected abstract Ingredient getTemptItems();

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
        this.goalSelector.add(1, new EscapeDangerGoal(this, 1.4));
        this.goalSelector.add(3, new TemptGoal(this, 1.15, getTemptItems(), false));
        this.goalSelector.add(5, new WanderAroundFarGoal(this, 1.0));
        this.goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 8.0f));
        this.goalSelector.add(7, new LookAroundGoal(this));
    }

    @Override
    public boolean canImmediatelyDespawn(double distanceSquared) {
        return false;
    }
}
