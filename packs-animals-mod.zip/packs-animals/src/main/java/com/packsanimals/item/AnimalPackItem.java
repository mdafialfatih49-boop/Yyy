package com.packsanimals.item;

import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.function.Supplier;

/** Item "Pack": klik kanan (di blok atau di udara) untuk membuka dan men-spawn isinya. */
public class AnimalPackItem extends Item {

    public record Entry(Supplier<EntityType<? extends MobEntity>> type, int count) {}

    private final Entry[] contents;

    public AnimalPackItem(Settings settings, Entry... contents) {
        super(settings);
        this.contents = contents;
    }

    /** Klik kanan pada blok: hewan muncul di atas sisi blok yang diklik. */
    @Override
    public ActionResult useOnBlock(ItemUsageContext ctx) {
        World world = ctx.getWorld();
        PlayerEntity player = ctx.getPlayer();
        if (!world.isClient && world instanceof ServerWorld sw) {
            BlockPos pos = ctx.getBlockPos().offset(ctx.getSide());
            openPack(sw, player, ctx.getStack(), Vec3d.ofBottomCenter(pos));
        }
        return ActionResult.success(world.isClient);
    }

    /** Klik kanan di udara: hewan muncul ~2 blok di depan pemain. */
    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        if (!world.isClient && world instanceof ServerWorld sw) {
            Vec3d look = player.getRotationVector();
            Vec3d forward = new Vec3d(look.x, 0, look.z).normalize().multiply(2.0);
            openPack(sw, player, stack, player.getPos().add(forward));
        }
        return TypedActionResult.success(stack, world.isClient);
    }

    private void openPack(ServerWorld world, @Nullable PlayerEntity player, ItemStack stack, Vec3d center) {
        Random rand = world.random;

        for (Entry entry : contents) {
            for (int i = 0; i < entry.count(); i++) {
                MobEntity mob = entry.type().get().create(world);
                if (mob == null) continue;

                double x = center.x + (rand.nextDouble() - 0.5) * 2.0;
                double z = center.z + (rand.nextDouble() - 0.5) * 2.0;
                mob.refreshPositionAndAngles(x, center.y, z, rand.nextFloat() * 360f, 0f);

                // Hindari spawn di dalam blok: jika tidak muat, pindahkan ke posisi pemain.
                if (!world.isSpaceEmpty(mob) && player != null) {
                    mob.refreshPositionAndAngles(player.getX(), player.getY(), player.getZ(),
                            rand.nextFloat() * 360f, 0f);
                }

                mob.initialize(world, world.getLocalDifficulty(mob.getBlockPos()),
                        SpawnReason.MOB_SUMMONED, null, null);
                mob.setPersistent();
                world.spawnEntity(mob);
            }
        }

        BlockPos bp = BlockPos.ofFloored(center);
        world.playSound(null, bp, SoundEvents.BLOCK_BARREL_OPEN, SoundCategory.PLAYERS, 1.0f, 1.0f);
        world.playSound(null, bp, SoundEvents.ENTITY_CHICKEN_EGG, SoundCategory.PLAYERS, 1.0f, 0.8f);
        world.spawnParticles(ParticleTypes.POOF, center.x, center.y + 0.5, center.z,
                20, 0.5, 0.4, 0.5, 0.02);

        if (player != null) {
            if (!player.getAbilities().creativeMode) stack.decrement(1);
            player.getItemCooldownManager().set(this, 10);
        }
    }

    @Override
    public void appendTooltip(ItemStack stack, @Nullable World world, List<Text> tooltip, TooltipContext ctx) {
        tooltip.add(Text.translatable("item.packsanimals.pack.contains").formatted(Formatting.GRAY));
        for (Entry e : contents) {
            tooltip.add(Text.literal(" " + e.count() + "x ").append(e.type().get().getName())
                    .formatted(Formatting.YELLOW));
        }
        tooltip.add(Text.translatable("item.packsanimals.pack.hint").formatted(Formatting.DARK_GRAY));
    }
}
