package com.packsanimals;

import com.packsanimals.registry.ModEntities;
import com.packsanimals.registry.ModItems;
import com.packsanimals.registry.ModLoot;
import net.fabricmc.api.ModInitializer;
import net.minecraft.util.Identifier;

public class PacksAnimals implements ModInitializer {
    public static final String MOD_ID = "packsanimals";

    public static Identifier id(String path) {
        return new Identifier(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModEntities.register();
        ModItems.register();
        ModLoot.register();
    }
}
