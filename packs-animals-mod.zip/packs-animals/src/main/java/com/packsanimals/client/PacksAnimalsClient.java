package com.packsanimals.client;

import com.packsanimals.PacksAnimals;
import com.packsanimals.entity.CapybaraEntity;
import com.packsanimals.entity.MeerkatEntity;
import com.packsanimals.entity.OstrichEntity;
import com.packsanimals.registry.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.entity.model.ChickenEntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.OcelotEntityModel;
import net.minecraft.client.render.entity.model.PigEntityModel;
import net.minecraft.util.Identifier;

public class PacksAnimalsClient implements ClientModInitializer {
    private static Identifier tex(String name) {
        return PacksAnimals.id("textures/entity/" + name + ".png");
    }

    @Override
    public void onInitializeClient() {
        // Capybara: model babi (vanilla) + tekstur coklat
        EntityRendererRegistry.register(ModEntities.CAPYBARA, ctx ->
                new PackAnimalRenderer<CapybaraEntity, PigEntityModel<CapybaraEntity>>(ctx,
                        new PigEntityModel<>(ctx.getPart(EntityModelLayers.PIG)), 0.6f, 1.0f, tex("capybara")));

        // Ostrich: model ayam diperbesar 2.5x
        EntityRendererRegistry.register(ModEntities.OSTRICH, ctx ->
                new PackAnimalRenderer<OstrichEntity, ChickenEntityModel<OstrichEntity>>(ctx,
                        new ChickenEntityModel<>(ctx.getPart(EntityModelLayers.CHICKEN)), 0.3f, 2.5f, tex("ostrich")));

        // Meerkat: model ocelot diperkecil
        EntityRendererRegistry.register(ModEntities.MEERKAT, ctx ->
                new PackAnimalRenderer<MeerkatEntity, OcelotEntityModel<MeerkatEntity>>(ctx,
                        new OcelotEntityModel<>(ctx.getPart(EntityModelLayers.OCELOT)), 0.4f, 0.55f, tex("meerkat")));
    }
}
