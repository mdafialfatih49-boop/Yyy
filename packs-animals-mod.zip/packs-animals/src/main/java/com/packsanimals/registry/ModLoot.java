package com.packsanimals.registry;

import net.fabricmc.fabric.api.loot.v2.LootTableEvents;
import net.minecraft.item.Item;
import net.minecraft.loot.LootPool;
import net.minecraft.loot.LootTables;
import net.minecraft.loot.condition.RandomChanceLootCondition;
import net.minecraft.loot.entry.ItemEntry;
import net.minecraft.loot.provider.number.ConstantLootNumberProvider;
import net.minecraft.util.Identifier;

/** Pack juga bisa "ditemukan": disisipkan ke loot chest vanilla. */
public class ModLoot {
    public static void register() {
        LootTableEvents.MODIFY.register((resourceManager, lootManager, id, tableBuilder, source) -> {
            if (!source.isBuiltin()) return;
            if (id.equals(LootTables.VILLAGE_SAVANNA_HOUSE_CHEST) || id.equals(LootTables.SIMPLE_DUNGEON_CHEST)) {
                tableBuilder.pool(pool(ModItems.SAVANNA_PACK, 0.30f));
            }
            if (id.equals(LootTables.JUNGLE_TEMPLE_CHEST)) {
                tableBuilder.pool(pool(ModItems.JUNGLE_PACK, 0.40f));
            }
        });
    }

    private static LootPool.Builder pool(Item item, float chance) {
        return LootPool.builder()
                .rolls(ConstantLootNumberProvider.create(1))
                .conditionally(RandomChanceLootCondition.builder(chance))
                .with(ItemEntry.builder(item));
    }
}
