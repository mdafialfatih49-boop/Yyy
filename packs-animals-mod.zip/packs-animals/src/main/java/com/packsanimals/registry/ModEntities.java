package com.packsanimals.registry;

import com.packsanimals.PacksAnimals;
import com.packsanimals.entity.CapybaraEntity;
import com.packsanimals.entity.MeerkatEntity;
import com.packsanimals.entity.OstrichEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

/**
 * Semua entitas di namespace "packsanimals". Tidak ada SpawnRestriction / biome spawn
 * yang ditambahkan, jadi hewan HANYA muncul lewat Pack (atau spawn egg / command).
 */
public class ModEntities {
    public static final EntityType<CapybaraEntity> CAPYBARA = Registry.register(Registries.ENTITY_TYPE,
            PacksAnimals.id("capybara"),
            FabricEntityTypeBuilder.<CapybaraEntity>create(SpawnGroup.CREATURE, CapybaraEntity::new)
                    .dimensions(EntityDimensions.fixed(0.9f, 0.9f)).trackRangeBlocks(64).build());

    public static final EntityType<OstrichEntity> OSTRICH = Registry.register(Registries.ENTITY_TYPE,
            PacksAnimals.id("ostrich"),
            FabricEntityTypeBuilder.<OstrichEntity>create(SpawnGroup.CREATURE, OstrichEntity::new)
                    .dimensions(EntityDimensions.fixed(1.0f, 1.9f)).trackRangeBlocks(64).build());

    public static final EntityType<MeerkatEntity> MEERKAT = Registry.register(Registries.ENTITY_TYPE,
            PacksAnimals.id("meerkat"),
            FabricEntityTypeBuilder.<MeerkatEntity>create(SpawnGroup.CREATURE, MeerkatEntity::new)
                    .dimensions(EntityDimensions.fixed(0.4f, 0.5f)).trackRangeBlocks(64).build());

    public static void register() {
        FabricDefaultAttributeRegistry.register(CAPYBARA, CapybaraEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(OSTRICH, OstrichEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(MEERKAT, MeerkatEntity.createAttributes());
    }
}
