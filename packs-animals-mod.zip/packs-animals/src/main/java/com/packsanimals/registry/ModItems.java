package com.packsanimals.registry;

import com.packsanimals.PacksAnimals;
import com.packsanimals.item.AnimalPackItem;
import com.packsanimals.item.AnimalPackItem.Entry;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;

public class ModItems {
    // Supplier dipakai supaya urutan inisialisasi class aman.
    public static final Item SAVANNA_PACK = item("savanna_pack",
            new AnimalPackItem(new FabricItemSettings().maxCount(16),
                    new Entry(() -> ModEntities.OSTRICH, 2),
                    new Entry(() -> ModEntities.MEERKAT, 3)));

    public static final Item JUNGLE_PACK = item("jungle_pack",
            new AnimalPackItem(new FabricItemSettings().maxCount(16),
                    new Entry(() -> ModEntities.CAPYBARA, 3)));

    // Spawn egg untuk testing / kreatif
    public static final Item CAPYBARA_EGG = item("capybara_spawn_egg",
            new SpawnEggItem(ModEntities.CAPYBARA, 0x8B6946, 0x5A4630, new FabricItemSettings()));
    public static final Item OSTRICH_EGG = item("ostrich_spawn_egg",
            new SpawnEggItem(ModEntities.OSTRICH, 0x3C322D, 0xE8D8C0, new FabricItemSettings()));
    public static final Item MEERKAT_EGG = item("meerkat_spawn_egg",
            new SpawnEggItem(ModEntities.MEERKAT, 0xC2A06E, 0x5A4630, new FabricItemSettings()));

    private static Item item(String name, Item item) {
        return Registry.register(Registries.ITEM, PacksAnimals.id(name), item);
    }

    public static final ItemGroup GROUP = Registry.register(Registries.ITEM_GROUP,
            PacksAnimals.id("main"),
            FabricItemGroup.builder()
                    .icon(() -> new ItemStack(SAVANNA_PACK))
                    .displayName(Text.translatable("itemGroup.packsanimals"))
                    .entries((ctx, entries) -> {
                        entries.add(SAVANNA_PACK);
                        entries.add(JUNGLE_PACK);
                        entries.add(CAPYBARA_EGG);
                        entries.add(OSTRICH_EGG);
                        entries.add(MEERKAT_EGG);
                    }).build());

    public static void register() { /* memicu static init class ini */ }
}
