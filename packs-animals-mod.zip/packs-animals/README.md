# PACKS Animals (Fabric 1.20.1)

Build: `./gradlew build` -> `build/libs/packs-animals-1.0.0.jar`
Test:  `./gradlew runClient`

Jika belum ada gradle wrapper: salin `gradlew`, `gradlew.bat`, folder `gradle/` dari template
https://github.com/FabricMC/fabric-example-mod (Gradle 8.5), atau jalankan `gradle wrapper --gradle-version 8.5`.
Butuh JDK 17.

Tes cepat in-game:
  /give @s packsanimals:savanna_pack
  /give @s packsanimals:jungle_pack
